This package is cloned from https://github.com/davideicardi/live-plugin-manager

Modified to fit the obsidian sandbox.


installed packages
lockfile url-join